# braintumor > 2025-05-14 1:45pm
https://universe.roboflow.com/vtec/braintumor-x9pcc

Provided by a Roboflow user
License: CC BY 4.0

